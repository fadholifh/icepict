<?php
session_start();
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_konek = "127.0.0.1";
$database_konek = "social_photo";
$username_konek = "root";
$password_konek = "";
$konek = mysql_pconnect($hostname_konek, $username_konek, $password_konek) or trigger_error(mysql_error(),E_USER_ERROR); 
?>