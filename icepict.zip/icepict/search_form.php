<form id="form1" name="form1" method="get" action="search.php">
  <label for="q"></label>
  <table class="table">
    <tr>
      <td><input type="text" name="q" id="q" class="form form-control"/></td>
      <td><button type="submit" name="button" id="button" value="Search" class="btn btn-success"><i class="fa fa-search"></i> Search</button>
      </td>
    </tr>
  </table>
</form>
